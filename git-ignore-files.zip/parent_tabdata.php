<?php


//This file contains the commonly used variables 

$parent_tab_info_array=array(1=>'My Home Page',2=>'Marketing',3=>'Sales',4=>'Support',5=>'Analytics',6=>'Inventory',7=>'Tools',8=>'Settings');


$parent_child_tab_rel_array=array(1=>array(),2=>array(),3=>array(6,4,2,7,),4=>array(88,88,),5=>array(),6=>array(34,),7=>array(8,25,33,69,38,71,91,92,92,94,94,),8=>array(),);



?>