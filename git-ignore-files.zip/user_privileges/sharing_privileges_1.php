<?php


//This is the sharing access privilege file

?>